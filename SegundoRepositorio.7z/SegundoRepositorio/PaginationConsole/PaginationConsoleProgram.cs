﻿using PaginationProgram;
namespace PaginationConsoleProgram;

class PaginationConsole
{
    public static void Main()
    {
        Console.Write("Página de Inicio: ");
        if(!int.TryParse(Console.ReadLine(), out int aux) || aux < 1)
        {
            Console.Write("Invalid Input.");
            Environment.Exit(0);
        }

        Console.Write("Cantidad de Páginas: ");
        if(!int.TryParse(Console.ReadLine(), out int aux2) || aux2 < 1)
        {
            Console.Write("Invalid Input.");
            Environment.Exit(0);
        }

        Pagination pagination = new Pagination();
        InputProgram.Input currentPage = new InputProgram.Input(aux);
        InputProgram.Input totalPages = new InputProgram.Input(aux2);
        OutputProgram.Output output = pagination.Result(currentPage, totalPages);

        Console.WriteLine(output.getResult());
    }
}